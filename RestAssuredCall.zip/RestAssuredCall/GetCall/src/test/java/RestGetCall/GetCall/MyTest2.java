package RestGetCall.GetCall;


import static com.jayway.restassured.RestAssured.given;

import org.apache.http.client.ClientProtocolException;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.Method;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.ExtractableResponse;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;


import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyTest2 extends BaseMethod {

	
	@Test
	void getComments() {
		
		boolean email= false;
		boolean body= false;
		String expectedBody= "veniam eos ab voluptatem in fugiat ipsam quis\nofficiis non qui\nquia ut id voluptates et a molestiae commodi quam\ndolorem enim soluta impedit autem nulla";
		String expectedEmail= "Cooper_Boehm@damian.biz";
		String expectedName= "pariatur aspernatur nam atque quis";
		
		
		//Specifying base uri
		RestAssured.baseURI="https://jsonplaceholder.typicode.com";
		
		//Request Object
		RequestSpecification httpRequest=RestAssured.given();
		
		//Response Object
		Response response=(Response) httpRequest.request().get("/comments");
		
		//Convert to Jsonpath
		JsonPath jsonpath=response.jsonPath();
		
		//print the status code & status line 
		int statusCode=response.getStatusCode();
		Assert.assertEquals(statusCode, 200,"Status code is not 200");
		
		String statusLine=response.getStatusLine();
		Assert.assertEquals(statusLine, "HTTP/1.1 200 OK", "Status line is not as expected");
		
		//get all the postID's and take the duplicate count of comments having postid 40
		List<Integer> postIds = response.body().jsonPath().getList("postId");
		Map<Integer, Integer> duplicateMap = getDuplicateCommentsCount(postIds);
		assertTrue(duplicateMap.get(40).equals(5),"Failed: postId:40 comments are not equal to 5");
		
		
		//Checking the value in each duplicate record to match with the expectd comments
		List<Integer> indexOfPostId = getIndexOfPostIds(postIds);
		List<String> nameList= jsonpath.getList("name");
		List<String> emailList= jsonpath.getList("email");
		List<String> bodyList= jsonpath.getList("body");

		for(int i=0;i<indexOfPostId.size();i++) {
			if(nameList.get(indexOfPostId.get(i)).equals(expectedName)) {
				System.out.println("Name matched.");
				email= emailList.get(indexOfPostId.get(i)).equals(expectedEmail);
				body= bodyList.get(indexOfPostId.get(i)).equals(expectedBody);
				break;
			}else {
				//System.out.println("PostID:40, Name doesn't matched with the expected: Current Name: "+nameList.get(indexOfPostId.get(i)));
				System.out.println("Continue checking for next value...");
			}
		}

		assertTrue(email,"Email doesn't contain expected Email: "+expectedEmail);
		assertTrue(body,"Body doesn't contain expected Body: "+expectedBody);
		System.out.println("Successfully verified the PostID 40 count and Comment message as below :");
		System.out.println("Expected Name:  " + expectedName); 
		System.out.println("Expected Email: " + expectedEmail);
		System.out.println("Expected Body: " + expectedBody);
		
				
	}
}