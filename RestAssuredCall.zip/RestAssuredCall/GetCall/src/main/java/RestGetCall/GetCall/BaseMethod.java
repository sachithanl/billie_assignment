package RestGetCall.GetCall;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class BaseMethod {

public Properties prop;
	
	

public Map<Integer, Integer> getDuplicateCommentsCount(List<Integer> postIds) {
	Map<Integer, Integer> countMap = new HashMap<Integer, Integer>();

	for (Integer item: postIds) {

		if (countMap.containsKey(item))
			countMap.put(item, countMap.get(item) + 1);
		else
			countMap.put(item, 1);
	}


	return countMap;
}

public List<Integer> getIndexOfPostIds(List<Integer> postIds) {
	List<Integer> index= new ArrayList<Integer>();

	for(int i=0;i<postIds.size();i++) {
		if(postIds.get(i).equals(40))
			index.add(i);
	}

	return index;
}
}